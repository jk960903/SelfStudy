package Practice602;
import util.Point;
public class ToStringEx {
	public static void main(String[] args) {
		System.out.println("2015152030 ���ر�");
		Point p = new Point(2,3);
		System.out.println(p.toString());
		System.out.println(p); 
		System.out.println(p + "�Դϴ�.");

	}
}
